package com.soira.eriscanface.adapter;


public interface OnConditionMet {

    void onConditionMet(int id);

    void onConditionMet(String id);

}
