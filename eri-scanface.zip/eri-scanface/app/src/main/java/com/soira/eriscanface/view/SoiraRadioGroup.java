package com.soira.eriscanface.view;


import android.content.Context;
import android.util.AttributeSet;
import android.widget.RadioGroup;

public class SoiraRadioGroup extends RadioGroup{

    public SoiraRadioGroup(Context context) {
        super(context);
    }

    public SoiraRadioGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

}
