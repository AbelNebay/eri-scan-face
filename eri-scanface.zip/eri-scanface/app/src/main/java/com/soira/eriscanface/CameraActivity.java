package com.soira.eriscanface;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.progress.scanner.ScanProgress;
import com.soira.eriscanface.utils.FaceRegister;
import com.soira.eriscanface.utils.StorageHelper;

import org.bytedeco.javacpp.opencv_core;

import java.io.File;

import static com.soira.eriscanface.AddStudent.temp_path;
import static org.bytedeco.javacpp.opencv_core.LINE_8;
import static org.bytedeco.javacpp.opencv_imgproc.CV_BGR2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.rectangle;


public class CameraActivity extends AbstractCameraPreviewActivity  {
    CvCameraPreview mOpenCvCameraView;
    protected ScanProgress progressLoader;
    boolean isRecognizing = false;

    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        mOpenCvCameraView = (CvCameraPreview) findViewById(R.id.camera_view);
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);

        progressLoader = ScanProgress.create(CameraActivity.this)
          .setStyle(ScanProgress.Style.BAR_DETERMINATE)
          .setLabel("Registering Student")
          .setMaxProgress(100)
          .setCancellable(true)
          .setCancellable(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        onBackPressed();
                    }
                })
          .show();

        new AsyncTask<Void, Void, Void>() {
          @Override
          protected Void doInBackground(Void... voids) {
            faceDetector = StorageHelper.loadClassifierCascade(CameraActivity.this, R.raw.frontalface);
            return null;
          }
        }.execute();
    }

    @Override
    public opencv_core.Mat onCameraFrame(opencv_core.Mat rgbaMat) {
        if (faceDetector != null) {
            opencv_core.Mat grayMat = new opencv_core.Mat(rgbaMat.rows(), rgbaMat.cols());

            cvtColor(rgbaMat, grayMat, CV_BGR2GRAY);

            opencv_core.RectVector faces = new opencv_core.RectVector();
            faceDetector.detectMultiScale(grayMat, faces, 1.25f, 3, 1,
                    new opencv_core.Size(absoluteFaceSize, absoluteFaceSize),
                    new opencv_core.Size(4 * absoluteFaceSize, 4 * absoluteFaceSize));
              if (faces.size() == 1) {
                  int x = faces.get(0).x();
                  int y = faces.get(0).y();
                  int w = faces.get(0).width();
                  int h = faces.get(0).height();
                  opencv_core.Mat duplicateMat=rgbaMat.clone();
                  rectangle(rgbaMat, new opencv_core.Point(x, y), new opencv_core.Point(x + w, y + h), opencv_core.Scalar.GREEN, 2, LINE_8, 0);

                  if(isRecognizing) {
                      return rgbaMat;
                  }
                  opencv_core.Mat croppedMat=new opencv_core.Mat(duplicateMat,faces.get(0));

                  try {
                      if (temp_path == null || !new File(temp_path).exists()){
                          throw new Exception();
                      }
                      isRecognizing = true;
                      faceRegister.debounceImageSaveCall(temp_path, croppedMat, 300);
                      croppedMat.release();
                      duplicateMat.release();
                      progressLoader.setProgress(faceRegister.getSavedImagesCount()*100/FaceRegister.getMaxImages());
                      if(faceRegister.getSavedImagesCount() >= FaceRegister.getMaxImages() ){
                          faceDetector = null;
                          this.runOnUiThread(new Runnable() {
                              public void run() {
                                  makeVibranium();
                                  Toast.makeText(CameraActivity.this, "Successfully added.", Toast.LENGTH_LONG).show();
                                  finish();
                              }
                          });
                      }
                  }catch (Exception e){
                      faceDetector = null;
                      Toast.makeText(CameraActivity.this, "Error", Toast.LENGTH_LONG).show();
                      finish();
                  } finally {
                      isRecognizing = false;
                  }
                  duplicateMat.release();
              }
                grayMat.release();
            }
        return rgbaMat;
    }

    private void makeVibranium() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(200L);
    }
}
