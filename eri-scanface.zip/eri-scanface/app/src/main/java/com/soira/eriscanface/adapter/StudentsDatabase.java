package com.soira.eriscanface.adapter;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * The below database helper is used to store the given path according to their newly added one!
 * &amp; setting_layout bit more_dark.... PEACE!
 * */
public class StudentsDatabase extends SQLiteOpenHelper{

    private static final String STUDENT_DATABSE = "STUDENT_DATABASE_NATIVE";


    private static final String DATABASE_NAME = "STUDENT_DATABASE.db";
    private final String TABLE_NAME;

    public static final String ID = "ID";
    public static final String FULL_NAME = "FULL_NAME";
    public static final String SCHOOL = "SCHOOL";
    public static final String NUMBER = "NUMBER";
    public static final String ROUND = "ROUND";
    public static final String GENDER = "GENDER";
    public static final String STREAM = "STREAM";

    /**
     * noy constructor with
     * @param context
     * Author       : Abel Nebay
     * College      : Mai-Nefhi College of Science
     * Department   : Applied Biology IV Year
     * E-mail       : abelnebay555@gmail.com
     * Website      : https://www.leafpedia.com
     * Company      : Leaf Pedia, Inc.
     * Foundation   : SoiraPlayer, Inc.
     * Tel          : +291-7276-749
     * Year         : 2023 - Tesseney, Asmara - Eritrea, Norther East Africa @Earth {#3 Planet}
     * */
    StudentsDatabase(Context context, String TABLE_NAME) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = TABLE_NAME;
    }

    public StudentsDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.TABLE_NAME = STUDENT_DATABSE;
    }

    /**
     * onCreate for creating the existing or new table by the name
     * */
    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + ID + " TEXT, " + FULL_NAME + " TEXT, " + SCHOOL + " TEXT, " + NUMBER + " TEXT PRIMARY KEY, " + ROUND + " TEXT, " + GENDER + " TEXT, " + STREAM + " TEXT)");

    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public Cursor getAllData(){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.rawQuery("Select * from " + TABLE_NAME, null);
    }

    public Cursor getDataAt(String column, String value) {
        SQLiteDatabase database = this.getWritableDatabase();
        try{
            return database.rawQuery("SELECT * from " + TABLE_NAME + " WHERE " + column + " =\"" + value + "\"", null);
        }catch (Exception e){
            try {
                return database.rawQuery("SELECT * from " + TABLE_NAME + " WHERE " + column + " =\'" + value + "\'", null);
            }catch (Exception a){
                return null;
            }
        }
    }

    @Nullable
    public String getValueAt(String column, String entry, String req_col){
        Cursor cursor = getDataAt(column, entry);
        String value = null;
        if (cursor != null && cursor.moveToFirst()){
            value = cursor.getString(cursor.getColumnIndex(req_col));
            cursor.close();
        }
        return value;
    }

    public boolean updateWhole(String id, String full_name, String school, String number, String round, String gender, String stream){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, id);
        contentValues.put(FULL_NAME, full_name);
        contentValues.put(SCHOOL, school);
        contentValues.put(ROUND, round);
        contentValues.put(GENDER, gender);
        contentValues.put(STREAM, stream);
        int result = database.update(TABLE_NAME, contentValues, NUMBER + "=?", new String[]{number});
        database.close();
        return result > 0;
    }

    public boolean updateData(String number, String column, String updating){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(column, updating);
        int result = database.update(TABLE_NAME, contentValues, NUMBER + "=?", new String[]{number});
        database.close();
        return result > 0;
    }

    public boolean insertData(String id, String full_name, String school, String number, String round, String gender, String stream){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, id);
        contentValues.put(FULL_NAME, full_name);
        contentValues.put(SCHOOL, school);
        contentValues.put(NUMBER, number);
        contentValues.put(ROUND, round);
        contentValues.put(GENDER, gender);
        contentValues.put(STREAM, stream);
        long result = database.insert(TABLE_NAME, null, contentValues);
        database.close();
        return result != -1;
    }


    public boolean deleteData(String number){
        SQLiteDatabase database = this.getWritableDatabase();
        int i =  database.delete(TABLE_NAME, NUMBER + "=?", new String[]{number});
        database.close();
        return i > 0;
    }

}
