package com.soira.eriscanface;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;

import com.soira.eriscanface.adapter.AddStudentRecyclerAdapter;
import com.soira.eriscanface.adapter.OnConditionMet;
import com.soira.eriscanface.adapter.StudentsDatabase;
import com.soira.eriscanface.keyboard.SoftKeypax;
import com.soira.eriscanface.view.SoiraAutoCompleteTextView;
import com.soira.eriscanface.view.SoiraButton;
import com.soira.eriscanface.view.SoiraTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class AddStudent extends AppCompatActivity {
    RecyclerView stored_lister;
    SoiraAutoCompleteTextView search_stored;
    SoiraTextView warning_text;

    RelativeLayout waiting;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    SoiraTextView
            id_text, id,
            full_name_text, full_name,
            gender_text, gender,
            round_text, round,
            number_text, number,
            stream_text, stream,
            school_text, school;

    RelativeLayout outer_alert, inner_alert, bottomers;
    ScrollView media_info_panel;
    SoiraButton register_button, finish_button;
    ImageView clear_text;
    boolean opened = false, message_opened = false;

    @Nullable
    ArrayList<String> stored_students = new ArrayList<>();
    public static final String PASSWORD = "0000211954721516";
    private boolean copy_originals_db() {
        boolean copied = false;
        try{
            String dec_path = "/data/data/" + getPackageName() + "/databases";
            File file = new File(dec_path);
            if (!file.exists()){
                file.mkdirs();
            }
            InputStream input = getAssets().open("student_database.db");
            FileOutputStream output = new FileOutputStream(new File(dec_path + File.separator + "STUDENT_DATABASE.db"));
            byte[] capacity = new byte[51200];
            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(PASSWORD.getBytes(), "AES"), new IvParameterSpec(new byte[16]));
            OutputStream cipherOutput = new CipherOutputStream(output, cipher);
            while (true) {
                int dolly = input.read(capacity);
                if (dolly == -1) break;
                cipherOutput.write(capacity, 0, dolly);
            }
            copied = true;
            cipherOutput.close();
            output.close();
            input.close();
        }catch (Exception ignored){
            Toast.makeText(this, ignored.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return copied;
    }

    private void fetch_ournic(){
        File file = new File("/data/data/" + getPackageName() + "/databases/STUDENT_DATABASE.db");
        if (!file.exists()) {
            copy_originals_db();
        }
        if (stored_students.size() > 0){
            stored_students.clear();
        }
        Cursor cursor = new StudentsDatabase(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String id = cursor.getString(cursor.getColumnIndex(StudentsDatabase.ID));
                String full_name = cursor.getString(cursor.getColumnIndex(StudentsDatabase.FULL_NAME));
                String school = cursor.getString(cursor.getColumnIndex(StudentsDatabase.SCHOOL));
                String number = cursor.getString(cursor.getColumnIndex(StudentsDatabase.NUMBER));
                String round = cursor.getString(cursor.getColumnIndex(StudentsDatabase.ROUND));
                String gender = cursor.getString(cursor.getColumnIndex(StudentsDatabase.GENDER));
                String stream = cursor.getString(cursor.getColumnIndex(StudentsDatabase.STREAM));

                String combined = id + ":" + full_name + ":" + school + ":" + number + ":" + round + ":" + gender + ":" + stream;

                stored_students.add(combined);
            }while (cursor.moveToNext());
            cursor.close();
        }
        if (stored_students.size() == 0){
            search_stored.setEnabled(false);
            warning_text.setText("No student data.");
            warning_text.setVisibility(View.VISIBLE);
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
        }else {
            search_stored.setEnabled(true);
            warning_text.setVisibility(View.GONE);
            warning_text.setText("");
            set_whole();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_student_layout);

        init_views();
        sharedPreferences = getSharedPreferences("ABEL", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        init_listeners();

        requestPermissions();
    }

    private void setClosed(){
        waiting.setVisibility(View.GONE);
        inner_alert.animate().alpha(0f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                deprint_information();
                outer_alert.setVisibility(View.GONE);
                opened = false;
                message_opened = false;
                if (search_stored.isFocusable()){
                    search_stored.requestFocus();
                    SoftKeypax.openSoft(AddStudent.this, search_stored);
                    search_stored.setText("");
                }
            }
        });
        bottomers.animate().alpha(0f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.GONE);
            }
        });
    }



    private void setOpened(@NonNull String code_value){
        print_information(code_value);
        inner_alert.setAlpha(0f);
        bottomers.setAlpha(0f);

        SoftKeypax.hideSoft(this, R.id.add_student_layout, null);

        outer_alert.setVisibility(View.VISIBLE);

        bottomers.animate().alpha(1f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().alpha(1f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = false;
            }
        });
    }


    private void deprint_information(){
        media_info_panel.setVisibility(View.GONE);

        id.setText("");
        full_name.setText("");
        school.setText("");
        number.setText("");
        round.setText("");
        gender.setText("");
        stream.setText("");
    }

    String id_val, name_val, school_val, number_val, round_val, gender_val, stream_val;
    private void print_information(@NonNull String received) {
        media_info_panel.setVisibility(View.VISIBLE);
        String[] media_content = received.split(":");

        id_val = media_content[0];
        name_val = media_content[1];
        school_val = media_content[2];
        number_val = media_content[3];
        round_val = media_content[4];
        gender_val = media_content[5];
        stream_val = media_content[6];


        id.setText(" :  " + id_val);
        full_name.setText(" :  " + name_val);
        school.setText(" :  " + school_val);

        number.setText(" :  " + number_val);

        round.setText(" :  " + round_val);
        gender.setText(" :  " + gender_val);
        stream.setText(" :  " + stream_val);

    }

    private void init_views() {
        waiting = (RelativeLayout) findViewById(R.id.wait);

        stored_lister = (RecyclerView) findViewById(R.id.stored_medias);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.change_name);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        media_info_panel = (ScrollView) findViewById(R.id.media_info_panel);
        bottomers = (RelativeLayout) findViewById(R.id.bottomers);

        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        finish_button = (SoiraButton) findViewById(R.id.finish_button);
        register_button = (SoiraButton) findViewById(R.id.register_button);
        warning_text = (SoiraTextView) findViewById(R.id.warning);

        id = (SoiraTextView) findViewById(R.id.id);
        id_text = (SoiraTextView) findViewById(R.id.id_text);

        full_name = (SoiraTextView) findViewById(R.id.full_name);
        full_name_text = (SoiraTextView) findViewById(R.id.full_name_text);

        gender = (SoiraTextView) findViewById(R.id.gender);
        gender_text = (SoiraTextView) findViewById(R.id.gender_text);

        round = (SoiraTextView) findViewById(R.id.round);
        round_text = (SoiraTextView) findViewById(R.id.round_text);

        number = (SoiraTextView) findViewById(R.id.number);
        number_text = (SoiraTextView) findViewById(R.id.number_text);

        stream = (SoiraTextView) findViewById(R.id.stream);
        stream_text = (SoiraTextView) findViewById(R.id.stream_text);

        school = (SoiraTextView) findViewById(R.id.school);
        school_text = (SoiraTextView) findViewById(R.id.school_text);

        clear_text = (ImageView) findViewById(R.id.store_clear_text);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    private void init_listeners() {
        waiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });
        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (stored_students.size() == 0){
                    return;
                }
                String entered = search_stored.getText().toString();
                if (entered != null && entered.length() > 0){
                    ArrayList<String> found = new ArrayList<>();
                    for (int i = 0; i < stored_students.size(); i++){
                        String current = stored_students.get(i);
                        if (current.toLowerCase().contains(entered.toLowerCase())){
                            found.add(current);
                        }
                    }
                    if (found.size() == 0){
                        warning_text.setText("No student matches your search.");
                        warning_text.setVisibility(View.VISIBLE);
                        set_stored_lists(null);
                    }else {
                        warning_text.setVisibility(View.GONE);
                        warning_text.setText("");
                        set_stored_lists(found);
                    }
                }else {
                    set_whole();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp_path = OUTPUT + "/" + id_val;
                File file = new File(temp_path);
                if (!file.exists()) {
                    boolean created = file.mkdirs();
                    if (!created) {
                        Toast.makeText(AddStudent.this, "Can\'t create folder. Try to create manually\n\"ERI SCANTRON IMAGE DATABASE\" & then student ID folder in Internal Storage.", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                setClosed();
                Intent intent = new Intent(AddStudent.this, CameraActivity.class);
                startActivity(intent);

            }
        });
    }
    String OUTPUT = "storage/emulated/0/ERI SCANTRON IMAGE DATABASE";
    public static String temp_path = null;

    private void set_whole() {
        warning_text.setVisibility(View.GONE);
        warning_text.setText("");
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: stored_students){
            secondary.add(entry);
        }
        set_stored_lists(secondary);
    }

    @Nullable
    AddStudentRecyclerAdapter addStudentRecyclerAdapter;
    private void set_stored_lists(@Nullable ArrayList<String> entered) {
        if (entered == null || entered.size() == 0){
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
            return;
        }

        stored_lister.setLayoutManager(new LinearLayoutManager(this));
        addStudentRecyclerAdapter = new AddStudentRecyclerAdapter(AddStudent.this, entered, new OnConditionMet() {
            @Override
            public void onConditionMet(int id) {

            }

            @Override
            public void onConditionMet(@NonNull String values) {
                setOpened(values);
            }
        });
        stored_lister.setAdapter(addStudentRecyclerAdapter);
    }

    @Override
    public void onBackPressed() {
        if (opened){
            setClosed();
            return;
        }
        super.onBackPressed();
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 0);
        }else {
            fetch_ournic();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length == 3 && requestCode == 0) {
            if (grantResults[0] != 0 || grantResults[1] != 0 || grantResults[2] != 0) {
                Toast.makeText(this, "Permission is required. Please allow it.", Toast.LENGTH_SHORT).show();
                requestPermissions();
            }else {
                fetch_ournic();
            }
        }
    }

    public void back_home_history(View view) {
        onBackPressed();
    }

    public void nombre(View view) {
        Switch switch_button = (Switch)view;
        if (switch_button.isChecked()){
            search_stored.setInputType(InputType.TYPE_CLASS_TEXT);
        }else {
            search_stored.setInputType(InputType.TYPE_CLASS_NUMBER);
        }
    }
}
