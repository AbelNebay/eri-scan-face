package com.soira.eriscanface.view;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.RadioButton;

public class SoiraRadioButton extends RadioButton{

    private void establishFont(){
        if (getTag() != null){
            boolean what = getTag().equals("vip");
            if (what){
                setTypeface(Typeface.createFromAsset(getContext().getAssets(), "vip.ttf"));
                return;
            }
        }
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }

    public SoiraRadioButton(Context context) {
        super(context);
        establishFont();
        
    }

    public SoiraRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
        
    }

    public SoiraRadioButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
        
    }

}
