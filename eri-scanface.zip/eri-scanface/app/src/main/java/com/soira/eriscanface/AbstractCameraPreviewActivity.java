package com.soira.eriscanface;

import android.support.v7.app.AppCompatActivity;

import com.soira.eriscanface.utils.FaceRegister;

import org.bytedeco.javacpp.opencv_objdetect;


abstract  public class AbstractCameraPreviewActivity
  extends AppCompatActivity
  implements CvCameraPreview.CvCameraViewListener
{
  public CvCameraPreview cameraView;
  public int absoluteFaceSize = 0;
  public opencv_objdetect.CascadeClassifier faceDetector;
  FaceRegister faceRegister=new FaceRegister();

  @Override
  public void onCameraViewStarted(int width, int height) {
    absoluteFaceSize = (int) (width * 0.32f);
  }

  @Override
  public void onCameraViewStopped() {

  }




}
