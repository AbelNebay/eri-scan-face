package com.soira.eriscanface.keyboard;

// The following class is illustrated inorder to maintain the effects of setting_layout keyboard which is always visible during active data inputs.

// @author: b Nebay - Mai-Nefhi College of Science 2022
// © Copyright 2022 - Leaf Pedia, Inc. : SoiraProject Foundations™ and SoiraPlayer™ Modifications
// Tesseney, Asmara - Eritrea

// If there is any comment or required asking session, you can contact me with the below data addresses.

// email:   abelnebay555@gmail.com
// website: https://www.leafpedia.com/soira
// tel:     (00) +291-(727)-6749


import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.soira.eriscanface.R;


public final class SoftKeypax {

    public static void openSoft(final AppCompatActivity appCompatActivity, final EditText editText){
        InputMethodManager inputMethodManager = (InputMethodManager) appCompatActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null){
            inputMethodManager.showSoftInput(editText, 1);
        }
    }

    public static void hideSoft(final AppCompatActivity appCompatActivity, int resource, View view){
        if (view == null){
            view = appCompatActivity.getCurrentFocus();
        }
        if (view != null){
            final InputMethodManager inputMethodManager = (InputMethodManager) appCompatActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputMethodManager != null){
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0, null);
                appCompatActivity.findViewById(resource).requestFocus();
            }
        }
    }

    public static void hideSoft(final AppCompatActivity appCompatActivity){
        hideSoft(appCompatActivity, R.id.activity_main, null);
    }
}
