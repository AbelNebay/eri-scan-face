package com.soira.eriscanface.view;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

public class SoiraButton extends Button{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }


    public SoiraButton(Context context) {
        super(context);
        establishFont();
    }

    public SoiraButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public SoiraButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
