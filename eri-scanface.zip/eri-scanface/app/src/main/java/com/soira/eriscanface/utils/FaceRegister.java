package com.soira.eriscanface.utils;

import org.bytedeco.javacpp.opencv_core;

import java.io.File;
import java.io.IOException;

import static org.bytedeco.javacpp.opencv_imgcodecs.imwrite;
import static org.bytedeco.javacpp.opencv_imgproc.resize;

public class FaceRegister{
    private static final int maxImages = 30;
    private int savedImagesCount=0;

    public static int getMaxImages() {
        return maxImages;
    }

    private void saveMatToImg(String path, opencv_core.Mat mat) throws IOException {
        opencv_core.Mat resizedImage = new opencv_core.Mat();
        opencv_core.Size size = new opencv_core.Size(200, 200);
        resize(mat, resizedImage, size);
        if (savedImagesCount < getMaxImages()) savedImagesCount++;

        String filename = "pic" + savedImagesCount + ".jpeg";
        File file = new File(path, filename);
        filename = file.toString();
        boolean saved = imwrite(filename,resizedImage);
        if(!saved)
            throw new IOException("Failed to save image: "+filename+" to external storage!");
    }

    public int getSavedImagesCount() {
        return savedImagesCount;
    }

    private long lastDebounceTime;
    public void debounceImageSaveCall(String path, opencv_core.Mat mat, long delay) throws  IOException{
        long lastClickTime = lastDebounceTime;
        long now = System.currentTimeMillis();

        if (now - lastClickTime > delay) {
            lastDebounceTime = now;
            saveMatToImg(path, mat);
        }
    }
}
